﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductosConInterface
{
    public interface IProducto //solo metodos
    {
        double CalcularPrecio();
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProductosConInterface
{
    public partial class FrmProductos : Form
    {

        #region Enumeracion TipoProducto
        enum TipoProducto
        {
            Suelto,Pack
        }
        List<IProducto> lProductos = new List<IProducto>();
        TipoProducto miTipo;

        #endregion

        public FrmProductos()
        {
            InitializeComponent();
            miTipo=TipoProducto.Suelto;
        }

        private void rbtSuelto_CheckedChanged(object sender, EventArgs e)
        {
            this.lblMedida.Text = "Medida:";
            miTipo = TipoProducto.Suelto;
        }

        private void btnPack_CheckedChanged(object sender, EventArgs e)
        {
            this.lblMedida.Text = "Cantidad";
            miTipo = TipoProducto.Pack;
        }

        private void btnCargarProductos_Click(object sender, EventArgs e)
        {
            //Validar datos de entrada

            int cod = int.Parse(txtCodigo.Text);
            string nom = txtNombre.Text;
            double pre = double.Parse(txtPrecio.Text);
            int x = int.Parse(txtMedidaCantidad.Text);

            //if(rbtSuelto.Checked) 
            if(miTipo==TipoProducto.Suelto)
            {
                Suelto s = new Suelto(cod,nom,pre,x);
                lProductos.Add(s);
            }
            else
            {
                Pack p = new Pack(cod,nom,pre,x);
                lProductos.Add(p);
            }

            lstProductos.Items.Clear();
            lstProductos.Items.AddRange(lProductos.ToArray());

        }

        private void btnMostrarTotal_Click(object sender, EventArgs e)
        {
            double total = 0;

            foreach (IProducto p in lProductos)
            {
                total += p.CalcularPrecio();
            }
            txtTotal.Text = total.ToString();
        }
    }
}

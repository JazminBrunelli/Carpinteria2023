﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductosConInterface
{
    public abstract class Producto : IProducto
    {
        public int Codigo { get; set; } // porp tap tap

        public string Nombre { get; set; }

        public double Precio { get; set; }


        public Producto(int cod,string nom, double pre) //ctor tap tap
        {
            Codigo= cod;
            Nombre= nom;    
            Precio= pre;
        }

        public abstract double CalcularPrecio();
        

        public override string ToString()
        {
            return Codigo + " - " + Nombre + " - $" +CalcularPrecio(); 
        }


    }
}
